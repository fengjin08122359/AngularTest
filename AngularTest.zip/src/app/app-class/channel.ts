export class Channel {
  pk: string
  name: string
  type: string
  memo: string
  monitor: string
  linkType: string
  publicNo: string
  appId: string
  appSecret: string
  sendType: string
  sendLink: string
}
