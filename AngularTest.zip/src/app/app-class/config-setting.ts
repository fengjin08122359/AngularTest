export class ConfigSetting {
  robot: string
  department: string
  visitorInformation: string
  leaveMessage: string
  satisfaction: string
  workTime: string
  startTime: string
  endTime: string
  adv: string
  question: string
}
