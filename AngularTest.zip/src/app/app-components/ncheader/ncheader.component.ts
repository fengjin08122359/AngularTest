import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ncheader',
  templateUrl: './ncheader.component.html',
  styleUrls: ['./ncheader.component.css']
})
export class NcheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
