import { Channel }      from '../../app-class/Channel';

export const CHANNEL: Channel= {
  pk: '',
  name: '',
  type: 'web',
  memo: '',
  monitor: '1',
  linkType: '1',
  publicNo: '',
  appId: '',
  appSecret: '',
  sendType: '',
  sendLink: ''
}