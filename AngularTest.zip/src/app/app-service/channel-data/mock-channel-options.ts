export const CHANNELOPTIONS = [{
  value: 'web',
  label: 'PC'
}, {
  value: 'wx',
  label: '微信'
}, {
  value: 'app',
  label: 'App'
}]