import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pc-appearance',
  templateUrl: './pc-appearance.component.html',
  styleUrls: ['./pc-appearance.component.css']
})
export class PcAppearanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
