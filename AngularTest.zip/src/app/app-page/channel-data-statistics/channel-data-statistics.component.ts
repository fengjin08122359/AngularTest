import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-channel-data-statistics',
  templateUrl: './channel-data-statistics.component.html',
  styleUrls: ['./channel-data-statistics.component.css']
})
export class ChannelDataStatisticsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
