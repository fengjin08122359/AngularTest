import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-h5-appearance',
  templateUrl: './h5-appearance.component.html',
  styleUrls: ['./h5-appearance.component.css']
})
export class H5AppearanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
