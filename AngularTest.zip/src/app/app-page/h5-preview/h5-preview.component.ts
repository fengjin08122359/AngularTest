import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-h5-preview',
  templateUrl: './h5-preview.component.html',
  styleUrls: ['./h5-preview.component.css']
})
export class H5PreviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
