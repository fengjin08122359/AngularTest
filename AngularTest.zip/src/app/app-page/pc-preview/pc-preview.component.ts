import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pc-preview',
  templateUrl: './pc-preview.component.html',
  styleUrls: ['./pc-preview.component.css']
})
export class PcPreviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
